import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { ActivatedRoute,Router } from '@angular/router';
import * as moment from 'moment';
import {DatePipe} from '@angular/common'

export default moment;

import { RestServService} from '../rest-serv.service';
import { IUserData } from '../IData';

@Component({
  selector: 'app-create-module',
  templateUrl: './create-module.component.html',
  styleUrls: ['./create-module.component.css']
})
export class CreateModuleComponent implements OnInit {
  name = 'Angular';
  pageTitle:string;
  userData: IUserData;
  fields = [
    {
      type: "input",
      label: "Username",
      inputType: "text",
      name: "username",
      validations: [
        {
          name: "required",
          validator: "required",
          message: "Name Required"
        },
        {
          name: "pattern",
          validator: "^[a-zA-Z]+$",
          message: "Accept only text"
        }
      ]
    }, {
      type: "password",
      label: "Password",
      inputType: "text",
      name: "password",
      validations: [
        {
          name: "required",
          validator: "required",
          message: "Password Required"
        }
      ]
    }, {
      type: "email",
      label: "Email",
      inputType: "email",
      name: "email",
      validations: [
        {
          name: "pattern",
          validator: "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",
          message: "Enter only mail id"
        }
      ]
    }, {
      type: "phone",
      label: "Phone",
      inputType: "phone",
      name: "phone",
      validations: [
        {
          name: "pattern",
          validator: "",
          message: "Enter only numbers"
        }
      ]
    },{
      type: "textarea",
      label: "Address",
      inputType: "textarea",
      name: "address",
      validations: [
        {
          name: "required",
          validator: "required",
          message: "Address is Required"
        }
      ]
    },{
      type: "checkbox",
      label: "Willingness",
      inputType: "checkbox",
      name: "willingness",
      Options: ['Books', 'TV', 'Videogames'],
      validations: [
        {
        }
      ]
    },{
      type: "date",
      label: "DateOfBirth",
      inputType: "date",
      name: "dateOfBirth",
      validations: [
        {
        }
      ]
    },{
      type: "radio",
      label: "Gender",
      inputType: "radio",
      name: "gender",
      Options: ['Male', 'Female'],
      validations: [
        {
        }
      ]
    },{
      type: "select",
      label: "Gender",
      inputType: "select",
      name: "gender",
      Options: ['Male', 'Female'],
      validations: [
        {
        }
      ]
    }
  ];
  dynamicForm: FormGroup;
  constructor(
      private route: ActivatedRoute,
      private userService: RestServService,
      private router: Router) {
    const controls = {};
    this.fields.forEach(res => { 
      const validationsArray = [];
      res.validations.forEach(val => {
        if (val.name === 'required') {
          validationsArray.push(
            Validators.required
          );
        }
        if (val.name === 'pattern') {
          validationsArray.push(
            Validators.pattern(val.validator)
          );
        }
      });
      controls[res.label] = new FormControl('', validationsArray);
      if(res.Options){
        res.Options.forEach(val => {
          controls[val] = new FormControl('', validationsArray);
        });
      }     
    });
    this.dynamicForm = new FormGroup(controls);
  }

  onSubmit() {
    console.log(this.dynamicForm.value);
  }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      const empId = +params.get('id');
      if (empId) {
        this.pageTitle = 'Edit User';
        this.getUserDetails(empId);
      } else {
        this.pageTitle = 'Create User';
        this.userData = {
          id: null,
          userName: '',
          password: '',
          email: '',
          phone: null,
          address: '',
          willingness: '',
          dateOfBirth: Date = null,
          gender: ''
        };
      }
    });
  }
  getUserDetails(id: number) {
      this.userService.getUser(id)
        .subscribe(
          (user: IUserData) => {
            this.userData = user;
            this.editEmployee(user);
          },
          (err: any) => console.log(err)
        );
  }
  
  editEmployee(user: IUserData) {
    console.log("user: ", user)
    this.dynamicForm.patchValue({
      Username: user.userName,
      Password: user.password,
      Email: user.email,
      Phone: user.phone,
      Address: user.address,
      Willingness: user.willingness,
      DateOfBirth: new Date().toISOString(),//new Date,
      Gender: user.gender
    });
  //const currentDate = new Date().toISOString().substring(0, 10);
  //this.dynamicForm.controls['DateOfBirth'].setValue(currentDate); // Working
  let dp = new DatePipe(navigator.language);
    let p = 'y-MM-dd';
    let dtr = dp.transform(user.dateOfBirth, p ); //dp.transform(new Date(), p );
    this.dynamicForm.controls['DateOfBirth'].setValue(dtr);
  }
}
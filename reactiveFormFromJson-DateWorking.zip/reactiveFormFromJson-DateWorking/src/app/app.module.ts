import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http'; 

import { CreateModuleComponent } from './module1/create-module.component';
import { RestServService} from './rest-serv.service';
import { ListDataComponent } from './module1/list-data.component'

@NgModule({
  imports:      [ BrowserModule,
                  AppRoutingModule,
                  HttpClientModule, 
                  FormsModule, 
                  ReactiveFormsModule ],
  declarations: [ AppComponent, CreateModuleComponent, ListDataComponent ],
  bootstrap:    [ AppComponent ],
  providers: [RestServService]
})
export class AppModule { }

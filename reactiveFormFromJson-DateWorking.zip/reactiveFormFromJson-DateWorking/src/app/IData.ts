
export interface IUserData {
    id: number;
    userName: string;
    password: string;
    email: string;
    phone?: number;
    address: string;
    willingness: string;
    dateOfBirth: Date;
    gender: string;
}
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CreateModuleComponent } from './module1/create-module.component';
import { ListDataComponent } from './module1/list-data.component'

const appRoutes: Routes = [
    { path: 'list', component: ListDataComponent },
    { path: 'create', component: CreateModuleComponent },
    { path: 'edit/:id', component: CreateModuleComponent },
    { path: '', redirectTo: '/list', pathMatch: 'full' }
  ];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

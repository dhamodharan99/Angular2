import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestServService} from '../rest-serv.service';
import { IUserData } from '../IData';

@Component({
  selector: 'app-list-data',
  templateUrl: './list-data.component.html',
  styleUrls: ['./list-data.component.css']
})
export class ListDataComponent implements OnInit {

  users: IUserData[];

  constructor(private _userService: RestServService,
                private _router: Router) { }
  ngOnInit() {
    this._userService.getUsers().subscribe(
      (userList) => this.users = userList,
      (err) => console.log(err)
    );
  }
  editButtonClick(userId: number) {
    this._router.navigate(['/edit', userId]);
  }

}

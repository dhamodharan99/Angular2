import { Component,  OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, AbstractControl, FormArray } from '@angular/forms';
import { ActivatedRoute,Router } from '@angular/router';
import {RxFormBuilder } from "@rxweb/reactive-form-validators" 

@Component({
  selector: 'app-survey-entry',
  templateUrl: './survey-entry.component.html',
  styleUrls: ['./survey-entry.component.css']
})
export class SurveyEntryComponent implements OnInit {
  surveyDynamicForm:FormGroup;
  surveyData=[]; 
  active = 0;

  constructor() { }
 
  ngOnInit() {
    this.surveyData=
    [
      {
      stepName: 'Step 1',
      Controls: [
      {
      Field: 'FirstName',
      Type: 'text',
      Required: true,
      Length: 30,
      name: "required", 
      message: "First Name is required"
      },
      {
      Field: 'LastName',
      Type: 'text',
      Required: true,
      Length: 30,
      name: "required", 
      message: "Last Name is required"
      },
      {
      Field: 'Address',
      Type: 'textarea',
      Required: true,
      Length: 300,
      name: "required", 
      message: "Address is required"
      },
      ]
      },{
        stepName: 'Step 2',
        Controls: [
        {
        Field: 'Interested In?',
        Type: 'checkbox',
        Required: true,
        Options: ['Books', 'TV', 'Videogames']
        },
        ]
        }
        ]
    const surveycontrols = {};
    this.surveyData.forEach(res => {
      const validationsArray = [];
      res.Controls.forEach(val => {
        if (val.Required == true) {
          validationsArray.push(
            Validators.required
          );
        }
        if(val.Length){
          validationsArray.push(
            Validators.maxLength(val.Length)
          );
        }
        surveycontrols[val.Field] = new FormControl('', validationsArray);
        if(res.Controls[0].Options){
          res.Controls[0].Options.forEach(val => {
            surveycontrols[val] = new FormControl('');
          });
        }
      });
    });
    this.surveyDynamicForm = new FormGroup( surveycontrols)
    
  };
  onSubmit(){
    console.log("Survey Details: ", this.surveyDynamicForm.controls.FirstName.value);
    console.log("Survey Details: ", this.surveyDynamicForm.controls.LastName.value);
    console.log("Survey Details: ", this.surveyDynamicForm.controls.Address.value);
    console.log("Survey Details: ", this.surveyDynamicForm.controls.Books.value);
    console.log("Survey Details: ", this.surveyDynamicForm.controls.TV.value);
    console.log("Survey Details: ", this.surveyDynamicForm.controls.Videogames.value);
  }
  onNext(){
    this.active = this.active + 1;
  }
  onPrev(){
    this.active = this.active - 1;
  }

}
